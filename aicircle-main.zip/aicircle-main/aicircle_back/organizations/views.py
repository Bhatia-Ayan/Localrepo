from rest_framework import viewsets, generics

from base.views import AuthenticatedView
