# Third Party Stuff
from django.test import TestCase
from django.core.exceptions import ValidationError


class PasswordResetTestCase(TestCase):
    def setUp(self):
        pass