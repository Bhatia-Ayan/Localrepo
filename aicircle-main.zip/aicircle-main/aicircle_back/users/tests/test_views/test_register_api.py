# Third Party Stuff
from django.test import TestCase
from django.core.exceptions import ValidationError


class RegisterTestCase(TestCase):
    def setUp(self):
        pass