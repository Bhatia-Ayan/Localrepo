# Third Party Stuff
from django.test import TestCase
from django.core.exceptions import ValidationError


class PasswordChangeTestCase(TestCase):
    def setUp(self):
        pass