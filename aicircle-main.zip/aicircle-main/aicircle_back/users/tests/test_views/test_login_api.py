# Third Party Stuff
from django.test import TestCase
from django.core.exceptions import ValidationError


class LoginTestCase(TestCase):
    def setUp(self):
        pass