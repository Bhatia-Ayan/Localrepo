# Third Party Stuff
from django.test import TestCase
from django.core.exceptions import ValidationError


class ServicesTestCase(TestCase):
    def setUp(self):
        pass