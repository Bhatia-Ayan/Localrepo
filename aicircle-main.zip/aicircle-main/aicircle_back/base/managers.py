# Django imports.
from django.db.models import Manager


class AllObjectsManager(Manager):
    pass
