class UnknownAWSServiceException(Exception):
    pass
