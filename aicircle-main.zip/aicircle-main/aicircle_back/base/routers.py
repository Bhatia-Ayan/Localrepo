from rest_framework import routers

default_router = routers.DefaultRouter(trailing_slash=False)
