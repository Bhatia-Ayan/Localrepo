# AICircle Monorepo

This repository contains both the backend and frontend codebases for AICircle.

## Structure

- **back/**: Backend (Django)
- **front/**: Frontend (React/Vite)

## Documentation

- [Backend README](aicircle_back/README.md)
- [Frontend README](aicircle_front/README.md)